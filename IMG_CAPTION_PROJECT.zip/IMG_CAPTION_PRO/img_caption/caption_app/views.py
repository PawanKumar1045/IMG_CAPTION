from lib2to3.fixes.fix_input import context

from django.contrib.auth import authenticate,login
from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.http import HttpRequest
from setuptools.command.register import register
from django.contrib import messages
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from .forms import ImageUploadForm
from .models import ImageUpload
from .forms import CreateUserForm




def home_page(request):
    return render(request, 'caption_app/home_page.html')
def main_login(request):
    if request.method == 'POST':
        uname = request.POST.get('username')
        pass1 = request.POST.get('password')
        user = authenticate(request,username=uname,password=pass1)
        print(uname,pass1)
        if user is not None:
            login(request, user)
            return redirect('/home')
        else:
            messages.error(request, 'Invalid username or password')
            return redirect('login')


    return render(request,'caption_app/main_login.html')
def reg(request):
    form  = CreateUserForm()
    if request.method == 'POST':
        form  = CreateUserForm(request.POST)
        if form.is_valid():
            if form.cleaned_data['password1'] != form.cleaned_data['password2']:
                print('passno match')
                messages.error(request, 'Passwords do not match')
            else:
                form.save()
                return redirect('login')

    context = {'form':form}
    return render(request, 'caption_app/register.html',context=context)

def profile(request):
    curr_user = request.user
    return render(request, 'caption_app/profile.html', {'users': curr_user})
def about(request):
    return render(request,'caption_app/about.html')

def upload_image(request):
    if request.method == 'POST':
        form = ImageUploadForm(request.POST, request.FILES)

        if form.is_valid():
            img_instance = form.save()
            img_path = img_instance.image.path
            print(img_path)
            return HttpResponse("IMG UPLOADED")
    else:
        form = ImageUploadForm()
    return render(request, 'caption_app/upload_image.html', {'form': form})