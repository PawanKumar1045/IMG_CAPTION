from django.apps import AppConfig


class CaptionAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'caption_app'
